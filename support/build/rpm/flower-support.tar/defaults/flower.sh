export PATH=/opt/flower/bin:/usr/local/gcc/bin:/usr/local/bin:$PATH
export LD_LIBRARY_PATH=/opt/flower/lib:/usr/local/boost/lib:/usr/local/gcc/lib:/usr/local/gcc/lib64:/usr/local/lib:/usr/lib:$LD_LIBRARY_PATH
